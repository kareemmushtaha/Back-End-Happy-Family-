<?php

return [
    'site_title' => 'الأسرة السعيدة',
];
