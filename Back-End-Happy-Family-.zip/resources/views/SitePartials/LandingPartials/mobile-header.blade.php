<div class="mobile-menu">
    <a href="">عن المنصة</a>
    <a href="">قصص نجاح</a>
    <a href="">مميزاتنا</a>
    <a href="">الاشتراك</a>
    <a href="">طريقه عمل الموقع</a>
    <a href="">الأسئلة الشائعة</a>
    <a href="">اتصل بنا</a>
    <a href="">
        تسجيل الخروج
        <img style="width: 20px; height: 20px; margin-right: 30px;" src="{{asset('assets/site/images/exit.png')}}" alt=""/>
    </a>
</div>
