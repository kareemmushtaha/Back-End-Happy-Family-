
<div class="landing-light" id="our_advantages">
    <div class="landing-special">
        <h1>أهم ما يميزنا ؟؟</h1>
        <div class="landing-special-cards">
            <div>
                <div class="landing-special-image">
                    <img src="{{asset('assets/site/images/background-yellow.png')}}" alt=""/>
                    <img src="{{asset('assets/site/images/complete.png')}}" alt=""/>
                </div>
                <h2>{{settingContentAr('home_section_features_title_1')}} </h2>
                <h3>
                    {{settingContentAr('home_section_features_description_1')}}
                </h3>
            </div>
            <div>
                <div class="landing-special-image">
                    <img src="{{asset('assets/site/images/background-burble.png')}}" alt=""/>
                    <img src="{{asset('assets/site/images/secure.png')}}" alt=""/>
                </div>
                <h2>{{settingContentAr('home_section_features_title_2')}}</h2>
                <h3>
                    {{settingContentAr('home_section_features_description_2')}}
                </h3>
            </div>
            <div>
                <div class="landing-special-image">
                    <img src="{{asset('assets/site/images/background-blue.png')}}" alt=""/>
                    <img src="{{asset('assets/site/images/verify.png')}}" alt=""/>
                </div>
                <h2>{{settingContentAr('home_section_features_title_3')}} </h2>
                <h3>
                    {{settingContentAr('home_section_features_description_3')}}
                </h3>
            </div>
        </div>
    </div>
</div>
