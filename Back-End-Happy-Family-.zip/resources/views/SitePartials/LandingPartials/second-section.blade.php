<div class="landing-light">
    <img class="husband" src="{{asset('assets/site/images/husband.png')}}" alt=""/>
    <img class="world" src="{{asset('assets/site/images/world.png')}}" alt=""/>
    <div class="landing-blur">
        <img class="ring" src="{{asset('assets/site/images/ring.png')}}" alt=""/>
    </div>
    <div class="landing-about">
        <h1>
            {{settingContentAr('home_section_get_to_know_us_title')}}
        </h1>
        <div>
            {{settingContentAr('home_section_get_to_know_us_description')}}
        </div>
        <a href="">تعرف علينا اكثر ؟</a>
    </div>
</div>
