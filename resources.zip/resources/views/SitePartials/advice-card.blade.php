<a href="{{route('question_answer')}}">
    <div class="profile-bottom">
        <h2>انتقل الى الإرشادات<br/> والنصائح</h2>
        <div>
            <img src="{{asset('assets/site/images/arrow-left.png')}}" alt=""/>
        </div>
    </div>
</a>
